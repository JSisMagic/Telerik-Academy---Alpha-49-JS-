class SantaHelper {
  constructor() {
    this.wishes = {};
  }

  AddWish(item, price, child) {
    const wish = {
      item: item,
      price: Number(price).toFixed(2),
      child: child,
    };

    if (!this.wishes[child]) {
      this.wishes[child] = [];
    }
    this.wishes[child].push(wish);
    console.log('Wish added');
  }

  DeleteWishes(child) {
    if (!this.wishes[child]) {
      console.log('No Wishes found');
    } else {
      const numWishes = this.wishes[child].length;
      delete this.wishes[child];
      console.log(`${numWishes} Wishes deleted`);
    }
  }

  FindWishesByPriceRange(fromPrice, toPrice) {
    const matchingWishes = [];

    for (const child of Object.keys(this.wishes)) {
      this.wishes[child].forEach((wish) => {
        if (wish.price >= Number(fromPrice) && wish.price <= Number(toPrice)) {
          matchingWishes.push(wish);
        }
      });
    }

    matchingWishes.sort((wish1, wish2) => wish1.item.localeCompare(wish2.item));

    if (matchingWishes.length === 0) {
      console.log('No Wishes found');
    } else {
      matchingWishes.forEach((wish) => {
        console.log(`{${wish.item};${wish.child};${wish.price}}`);
      });
    }
  }

  FindWishesByChild(child) {
    if (this.wishes[child]) {
      const wishes = this.wishes[child];
      wishes.sort((wish1, wish2) => wish1.item.localeCompare(wish2.item));
      wishes.forEach((wish) => {
        console.log(`{${wish.item};${wish.child};${wish.price}}`);
      });
    } else {
      console.log('No Wishes found');
    }
  }
}

const n = +gets();
const santaHelper = new SantaHelper();

for (let i = 0; i < n; i++) {
  const line = gets().split(' ');
  const command = line[0];
  const data = line
    .filter((x) => x !== command)
    .join(' ')
    .split(';');

  santaHelper[command](...data);
}
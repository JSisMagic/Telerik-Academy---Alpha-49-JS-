class SantaList {
    constructor() {
        this.list = new Map();
    }

    addWish(item, price, name) {
        if (!this.list.has(name)) {
            this.list.set(name, [])
        }

        const wishList = this.list.get(name);
        wishList.push({
            item: item,
            name: name,
            price: Number.parseFloat(price)
        });
        this.list.set(name, wishList);

        return ('Wish added')
    }

    deleteWishes(name) {
        const wishList = this.list.get(name);

        if (wishList === undefined) {
            return 'No Wishes found';
        }
        const amountWishes = wishList.length;
        this.list.delete(name);
        return `${amountWishes} Wishes deleted`
    }

    transformFoundWishes(wishesArr) {
        wishesArr.sort((wish1, wish2) => {
            if (wish1.item > wish2.item) {
                return 1;
            }
            else if (wish1.item < wish2.item) {
                return -1
            }

            return 0
        })

        return wishesArr
            .map(wish => `{${wish.item};${wish.name};${(wish.price).toFixed(2)}}`)
            .join('\n')
    }

    findWishesByPriceRange(fromPrice, toPrice) {
        const itemsWithinRange = [];
        const wishLists = this.list.values();

        for (let wishList of wishLists) {
            for (let wish of wishList) {
                if (wish.price >= fromPrice && wish.price <= toPrice) {
                    itemsWithinRange.push(wish);
                }
            }
        }

        return itemsWithinRange.length ? this.transformFoundWishes(itemsWithinRange) : 'No Wishes found';
    }

    findWishesByChild(childName) {
        if (!this.list.has(childName)) {
            return 'No Wishes found';
        }

        return this.transformFoundWishes(this.list.get(childName));
    }
}

const santaL = new SantaList();

const engine = (command) => {
    const firstSpace = command.indexOf(' ');
    const funName = command.slice(0, firstSpace).toLowerCase();
    let funArgs = command.slice(firstSpace + 1).split(';');


    switch (funName) {
        case 'addwish':
            return santaL.addWish(...funArgs);
        case 'deletewishes':
            return santaL.deleteWishes(...funArgs);
        case 'findwishesbypricerange':
            funArgs = funArgs.map(arg => Number.parseFloat(arg))
            return santaL.findWishesByPriceRange(...funArgs);
        case 'findwishesbychild':
            return santaL.findWishesByChild(...funArgs);
        default:
            return 'Invalid Function';
    }
}

const numOfCommands = +gets();

for (let i = 0; i < numOfCommands; i++) {
    console.log(engine(gets()));
}
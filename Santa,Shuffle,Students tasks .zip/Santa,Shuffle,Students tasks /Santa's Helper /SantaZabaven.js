let input = [
    '36',
    'AddWish Beer Zagorka; 1.20;Zagorka AD',
    'AddWish Beer Zagorka Gold; 0.85;Zagorka AD',
    'AddWish Beer Kamenitza; 1.05;Kamenitza AD',
    'AddWish Rakiya Grozdova; 6.98;Peshtera AD',
    'AddWish Rakiya Muskatova; 7.33;Peshtera AD',
    'AddWish Mastika Peshtera; 8.22;Peshtera AD',
    'AddWish Rakiya; 12;Peshtera AD',
    'AddWish Rakiya Grozdova; 10.8;Vimprom Liaskovetz Ltd',
    'AddWish Rakiya; 12;Peshtera AD',
    'AddWish Beer Zagorka Draft; 0.76;Zagorka AD',
    'AddWish Vodka; 11.33;Peshtera AD',
    'AddWish Vodka; 12.36;Peshtera AD',
    'AddWish Vodka Nashenska; 4.66;Mente Corp',
    'AddWish Rakiya Nashenska; 3.7;Mente Corp',
    'AddWish Rakiya Nashenska; 3.7;Mente Corp',
    'AddWish Rakiya Mente; 1.25;Mente Corp',
    'AddWish Oslepitelna Rakiya; 0.96;Mente Corp',
    'AddWish Vodka Studentska; 2.45;Mente Corp',
    'AddWish Romsko Pivo; 0.36;Romsko Pivo AD',
    'AddWish Dolnoprobna Bira; 0.32;Romsko Pivo AD',
    'AddWish rakiya; 8.5;peshtera ad',
    'AddWish vodka; 9.6;peshtera ad',
    'DeleteWishes Zagorka AD',
    'DeleteWishes Zagorka AD',
    'AddWish Beer Zagorka; 1.2;Zagorka AD',
    'DeleteWishes zagorka ad',
    'AddWish Vodka; 8.3;Mente Corp',
    'FindWishesByChild Romsko Pivo AD',
    'FindWishesByChild romsko pivo ad',
    'AddWish IdeaPad Z560; 1536.5; Lenovo',
    'DeleteWishes Lenovo',
    'FindWishesByChild Lenovo',
    'FindWishesByPriceRange 1.20; 1.25',
    'FindWishesByPriceRange 0.00; 0.10',
    'FindWishesByPriceRange 3.0; 7',
    'FindWishesByPriceRange 0; 0.99',
]

let print = this.print || console.log;
let gets = this.gets || ((arr, index) => () => arr[index++])(input, 0);

const printAlphabetically = (arr) =>
    arr.map(o => ('{' + o.name + ';' + o.child + ';' + o.price.toFixed(2) + '}'))
        .sort()
        .join('\n')

const solve = () => {
    const map = new Map();
    const res = [];

    const n = +gets();

    for (let i = 0; i < n; i++) {
        const input = gets();
        const idx = input.indexOf(' ');
        const cmdName = input.substring(0, idx);
        const args = input.substring(idx + 1);

        if (cmdName === 'AddWish') {
            const [name, price, child] = args.split(';');

            if (!map.has(child)) {
                map.set(child, []);
            }
            map.get(child).push({
                name: name,
                price: Number(price),
                child: child
            });
            res.push('Wish added');

        } else if (cmdName === 'DeleteWishes') {
            if (!map.has(args) || map.get(args).length === 0) {
                res.push('No Wishes found');
            } else {
                res.push(map.get(args).length + ' Wishes deleted');
                map.get(args).length = 0;
            }

        } else if (cmdName === 'FindWishesByChild') {
            const wishes = map.get(args);

            res.push((wishes && wishes.length) ? printAlphabetically(wishes) : 'No Wishes found');

        } else {
            const [min, max] = args.split(';').map(Number);
            const wishes = [...map.values()]
                .reduce((r, v) => r.concat(v), [])
                .filter(o => min <= o.price && o.price <= max);

            res.push(wishes.length ? printAlphabetically(wishes) : 'No Wishes found');
        }

    }

    print(res.join('n'));
}

solve();
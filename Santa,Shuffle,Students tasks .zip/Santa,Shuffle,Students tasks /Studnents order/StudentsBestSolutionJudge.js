class LinkedListNode {
    constructor(value) {
        this.value = value;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    constructor(arr) {
        this.head = null;
        this.tail = null;
        this.count = 0;
        this.nodes = {};

        if (arr) {
            for (const value of arr) {
                this.push(value);
            }
        }
    }

    push(value) {
        const node = new LinkedListNode(value);
        this.nodes[value] = node;

        if (this.count === 0) {
            this.head = node;
            this.tail = node;
        } else {
            this.tail.next = node;
            node.prev = this.tail;
            this.tail = node;
        }

        this.count++;
        return this;
    }

    toArray() {
        const arr = [];

        let node = this.head;

        while (node) {
            arr.push(node.value);
            node = node.next;
        }

        return arr.join(' ');
    }

    moveBefore(value1, value2) {
        const node1 = this.nodes[value1];
        const node2 = this.nodes[value2];

        if (!node1 || !node2) return null;

        if (node1 === node2) return this;

        if (node1 === this.head) {
            this.head = node1.next;
            this.head.prev = null;
        } else if (node1 === this.tail) {
            this.tail = node1.prev;
            this.tail.next = null;
        } else {
            node1.prev.next = node1.next;
            node1.next.prev = node1.prev;
        }

        if (node2 === this.head) {
            node2.prev = node1;
            node1.next = node2;
            node1.prev = null;
            this.head = node1;
        } else {
            node2.prev.next = node1;
            node1.prev = node2.prev;
            node2.prev = node1;
            node1.next = node2;
        }

        return this;
    }
}

const [k, n] = gets().split(' ').map(Number);
const studentsArr = gets().split(' ');
const list = new DoublyLinkedList(studentsArr);

for (let i = 0; i < n; i++) {
    let current = gets().split(' ');
    let firstName = current[0];
    let secondName = current[1];
    list.moveBefore(firstName, secondName);
}

console.log(list.toArray());
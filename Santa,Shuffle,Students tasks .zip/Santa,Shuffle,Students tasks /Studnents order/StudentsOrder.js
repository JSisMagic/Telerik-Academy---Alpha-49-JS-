let input = [
    '7 4',
    'Emo Misho Ivanka Ginka Vancho Stancho Sashka',
    'Emo Misho',
    'Misho Emo',
    'Misho Sashka',
    'Sashka Stancho',
];

let print = this.print || console.log;
let gets =
    this.gets ||
    (
        (arr, index) => () =>
            arr[index++]
    )(input, 0);

const getStudentsOrder = () => {
    const studentMap = new Map();
    let headNode = null;

    const setOrder = (arr) => {
        let previousNode = null;

        for (let i = n - 1; i >= 0; i--) {
            const studentNode = {
                name: arr[i],
                next: studentMap.get(arr[i + 1]) || null,
                prev: null,
            };

            if (previousNode) {
                previousNode.prev = studentNode;
            }
            previousNode = studentNode;
            studentMap.set(arr[i], studentNode);
        }

        headNode = studentMap.get(arr[0]);
    };

    const rearrange = (studentName, targetName) => {
        const studentNode = studentMap.get(studentName);
        const targetNode = studentMap.get(targetName);

        deleteNode(studentNode);
        studentNode.next = targetNode;
        studentNode.prev = targetNode.prev;
        if (targetNode.prev) {
            targetNode.prev.next = studentNode;
        }
        targetNode.prev = studentNode;

        while (headNode.prev) {
            headNode = headNode.prev;
        }
    };

    const deleteNode = (node) => {
        if (node.prev) {
            node.prev.next = node.next;
        }
        if (node.next) {
            node.next.prev = node.prev;
        }
    };

    const logOrder = () => {
        const order = [];

        while (headNode) {
            order.push(headNode.name);
            headNode = headNode.next;
        }

        console.log(order.join(' '));
    };

    return {
        setOrder,
        rearrange,
        logOrder,
    };
};

const [n, k] = gets().split(' ').map(Number);
const data = gets().split(' ');

const students = getStudentsOrder();
students.setOrder(data);

for (let i = 0; i < k; i++) {
    const params = gets().split(' ');
    students.rearrange(...params);
}

students.logOrder();
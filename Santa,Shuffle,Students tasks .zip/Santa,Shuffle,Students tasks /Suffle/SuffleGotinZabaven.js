let input = [
    '10 5',
    '10 2 1 6 8',
];

let print = this.print || console.log;
let gets = this.gets || ((arr, index) => () => arr[index++])(input, 0);

const [total] = gets().split(' ').map(Number);
const forShuffling = gets().split(' ').map(Number);

const generateNodes = (total) => {
    const refs = Array.from({ length: total + 1 });

    let prev = null;
    for (let i = 1; i <= total; i++) {
        const newNode = {
            val: i,
            next: null,
            prev: prev
        }

        if (prev) prev.next = newNode;
        prev = newNode;

        // for last access

        refs[i] = newNode;
    };

    return refs;
}

const detach = (node) => {
    if (node.next) node.next.prev = node.prev;
    if (node.prev) node.prev.next = node.next;
}

const insertAfter = (left, right) => {
    if (left.next) left.next.prev = right;

    right.next = left.next;
    left.next = right;
    right.prev = left;
}

const getOutput = (nodes) => {
    let headNode = nodes.find(n => n && n.prev === null);
    let output = headNode.val;
    while (headNode.next) {
        output += ' ' + headNode.next.val;
        headNode = headNode.next;
    }

    return output;
}

const refs = generateNodes(total);

for (const shuffler of forShuffling) {
    const afterWhich = shuffler % 2 === 0
        ? shuffler / 2
        : Math.min(shuffler * 2, total);

    if (afterWhich !== shuffler) {
        detach(refs[shuffler]);
        insertAfter(refs[afterWhich], refs[shuffler]);
    }
}

print(getOutput(refs));
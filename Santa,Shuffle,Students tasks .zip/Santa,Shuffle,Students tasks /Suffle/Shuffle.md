# Shuffle

Your task is to implement a brand new algorithm for shuffling numbers. The numbers will be from  **1**  to  **N**. You will receive  **K**numbers, which will be the ones you will shuffle following the rules below:

-   If the number to be shuffled is even -> move it after the number with  **value = numberToBeShuffled / 2**  (i.e. if you need to shuffle  **4**  you need to move it after  **2**).
-   If the number to be shuffled is odd -> move it after the number with  **value = numberToBeShuffled * 2**  (i.e. if you need to shuffle  **3**  you need to move it after  **6**). If  **numberToBeShuffled * 2 > N**  move it after the number with value  **N**.
-   If the number to be shuffled should be moved after the same number -> do nothing.

# Input

-   Read from the standard input
-   On the first line, find the number  **N**  and  **K**
    -   **N**  - numbers will be from  **1**  to  **N**
    -   **K**  - the count of numbers which will be found on the next line of the input
-   On the next line there will be  **K**  numbers
-   The numbers to be shuffled (all in range from  **1**  to  **N**)

# Output

-   Print on the standard output
-   On a single line, print the shuffled numbers

# Constraints

-   1 <= N <= 100
-   1 <= K <= 400 000

# Sample tests

## Input

```
7 4
1 5 4 7

```

## Output

```
2 4 1 3 6 7 5

```

## Explanation

-   You have the numbers  **1 2 3 4 5 6 7**. First you need to move  **1**  which is odd, so we move it after  **1 * 2 = 2**  ->  **2 1 3 4 5 6 7**
-   Move  **5**  which is odd, so we should move it after  **5 * 2 = 10**, but it is greater than  **7**, so we move it after  **7**  ->  **2 1 3 4 6 7 5**
-   Move  **4**  which is even, so we move it after  **4 / 2 = 2**  ->  **2 4 1 3 6 7 5**
-   Move  **7**  which is odd, so we should move it after  **7 * 2 = 14**, but it is greater than  **7**, so we need to move it after  **7**, which is the number to be moved, so we do nothing ->  **2 4 1 3 6 7 5**

## Input

```
10 5
10 2 1 6 8

```

## Output

```
2 1 3 6 4 8 5 10 7 9

```

## Input

```
5 5
1 2 1 2 5

```

## Output

```
1 2 3 4 5
```
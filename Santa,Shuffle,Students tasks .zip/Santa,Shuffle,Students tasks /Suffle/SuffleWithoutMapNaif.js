let input = [
    '10 5',
    '10 2 1 6 8',
];

let print = this.print || console.log;
let gets = this.gets || ((arr, index) => () => arr[index++])(input, 0);

const [total, _] = gets().split(' ').map(Number);
const forShuffling = gets().split(' ').map(Number);

const numbers = Array.from({ length: total }, (_, i) => i + 1);

for (const shuffler of forShuffling) {
    const afterWhich = shuffler % 2 === 0
        ? shuffler / 2
        : Math.min(shuffler * 2, total);

    if (afterWhich !== shuffler) {
        const index1 = numbers.indexOf(shuffler);
        numbers.splice(index1, 1);

        const index2 = numbers.indexOf(afterWhich);
        numbers.splice(index2 + 1, 0, shuffler);
    }
}

print(numbers.join(' '));
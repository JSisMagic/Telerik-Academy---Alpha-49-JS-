function shuffleNumbers(N, K, numbers) {
    const nodes = generateNodes(N);
    const output = getOutput(nodes);

    for (const shuffler of numbers) {
        const afterWhich =
            shuffler % 2 === 0 ? shuffler / 2 : Math.min(shuffler * 2, N);
        if (afterWhich !== shuffler) {
            detach(nodes[shuffler]);
            insertAfter(nodes[afterWhich], nodes[shuffler]);
        }
    }

    return getOutput(nodes);
}

function generateNodes(total) {
    const nodes = Array.from({ length: total + 1 });

    let prev = null;
    for (let i = 1; i <= total; i++) {
        const newNode = {
            val: i,
            next: null,
            prev: prev,
        };

        if (prev) prev.next = newNode;

        prev = newNode;

        nodes[i] = newNode;
    }

    return nodes;
}

function detach(node) {
    if (node.next) node.next.prev = node.prev;
    if (node.prev) node.prev.next = node.next;
}

function insertAfter(left, right) {
    if (left.next) left.next.prev = right;

    right.next = left.next;
    left.next = right;
    right.prev = left;
}

function getOutput(nodes) {
    let headNode = nodes.find((n) => n && n.prev === null);
    let output = headNode.val;

    while (headNode.next) {
        output += ' ' + headNode.next.val;
        headNode = headNode.next;
    }

    return output;
}

const input = gets().split(' ');
const N = parseInt(input[0]);
const K = parseInt(input[1]);
const numbers = gets().split(' ').map(Number);

const result = shuffleNumbers(N, K, numbers);
print(result);